package com.example.itube;

public interface OnItemClickListener {
    void onItemClick(VideoLink videoLink);
}
